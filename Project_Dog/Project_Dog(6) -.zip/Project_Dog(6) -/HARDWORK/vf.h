#ifndef VF_H
#define VF_H

#include "sys.h"


void Vf_Init(void);

















#endif


