#ifndef _SPI_H
#define _SPI_H
#include "sys.h"

void SPI_GPIO_InitConfig(void);
u8 SPI5_ReadWriteByte(u8 TxData);

#endif
