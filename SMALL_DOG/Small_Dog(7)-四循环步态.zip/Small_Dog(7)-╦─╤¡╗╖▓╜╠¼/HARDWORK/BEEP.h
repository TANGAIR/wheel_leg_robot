#ifndef BEEP_H
#define BEEP_H
#include "stm32f4xx.h" 

void Beep_Init(void);
void Beep_OFF(void);
void Beep_ON(void);


#endif
